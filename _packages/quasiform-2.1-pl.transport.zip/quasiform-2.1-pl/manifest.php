<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'd39b4ef2e098af079f4bcb03f7dbe411',
      'native_key' => 'quasiform',
      'filename' => 'modNamespace/0d98c29422fb0202f55dcec680c7cbb3.vehicle',
      'namespace' => 'quasiform',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '57ed5e3088b3abd3cc1584d458685855',
      'native_key' => 1,
      'filename' => 'modCategory/aa3187c7b1223af7ed510df601894372.vehicle',
      'namespace' => 'quasiform',
    ),
  ),
);