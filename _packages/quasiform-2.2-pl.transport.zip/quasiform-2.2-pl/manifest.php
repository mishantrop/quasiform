<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'fce30ce1c3b29ccaf7ad395ff93acc33',
      'native_key' => 'quasiform',
      'filename' => 'modNamespace/76d00fa7a0168e3922a1be7508bfe762.vehicle',
      'namespace' => 'quasiform',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'f0658efe62135c2fd0ed0700c067a2ee',
      'native_key' => 1,
      'filename' => 'modCategory/abcdbd2bc20f1c9f9c2a534a3565a887.vehicle',
      'namespace' => 'quasiform',
    ),
  ),
);