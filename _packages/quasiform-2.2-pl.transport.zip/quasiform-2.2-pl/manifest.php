<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '1dd22f075bc50095043b4b92a1fdd13e',
      'native_key' => 'quasiform',
      'filename' => 'modNamespace/3987e8c2a2729569a16d6b34eb49510b.vehicle',
      'namespace' => 'quasiform',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '3d1133d74c736fc5ea62ae9a0408feb5',
      'native_key' => 1,
      'filename' => 'modCategory/6110a1f3d6a98fea9f3ab9c520c854f8.vehicle',
      'namespace' => 'quasiform',
    ),
  ),
);